Name: Noah Fuery
ID: 2377792
Chapman email: nfuery@chapman.edu
Course and section: CPSC-350-02
Assignment: PA1

Source files submitted: 
Model.cpp
Translator.cpp
FileProcessor.cpp
main.cpp

References:
docs.oracle.com
geeksforgeeks.org
stackoverflow.com

All references used for finding out c++ methods, mainly for reading and writing files
